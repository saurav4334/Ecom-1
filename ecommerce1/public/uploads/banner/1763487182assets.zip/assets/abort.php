<?php
require_once 'iprogress.php';
$progress = new iProgress('zip', 200);
$progress->abort();