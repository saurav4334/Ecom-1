This is a simple ZIP tool, which allows you to easily zip files/directories of your website. The goal was to be easy to use, with nice interface and to be able to zip large sites. It has a progress bar and the option to pause/continue a zip process. You can pause a zip process from one PC and continue it from another.

For the advanced users, the tool offers several options, which if properly configured can speed up the generation of the final zip archive.

The tool also has an option to exclude unwanted entries from the final zip file.